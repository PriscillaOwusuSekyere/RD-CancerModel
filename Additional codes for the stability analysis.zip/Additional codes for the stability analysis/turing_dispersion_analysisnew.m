function turing_dispersion_analysis()
    % Random seed for reproducibility
    rng(42);

    % Parameter ranges [min, max]
    ranges = [ ...
        6.8e-3, 0.0143;     % alpha1
        1.0e-3, 0.0210;     % alpha2
        2.0e-4, 0.0042;     % alpha3
        7.02e-4, 0.0147;    % q1
        7.2e-5, 0.0015;     % q2
        0.0162, 0.3392;     % gamma
        3.71e-4, 0.0078;    % beta
        0.1100, 2.3100;     % a1
        0.4621, 9.7030;     % a2
        0.4667, 9.7999;     % a3
        2e-5, 4.2e-4;       % d1
        0.0032, 0.0672;     % d2
        0.0032, 0.0672;     % d3
        1.2e-8, 2.52e-7;    % p10
        0.0205, 0.4307;     % p20
        0.1714, 3.6;        % p3
        4.2e-9, 8.82e-8;    % p11
        4.31e-4, 0.0091;    % p21
        1.0e-8, 2.1e-7;     % p12
        1.9487, 40.9231;    % p22
        3.3e-4, 0.0069;     % delta
        0.0018, 0.0381;     % xi
        2.4e-5, 5.04e-4;    % phi
        0.0136, 0.2856      % eta
    ];

    % Sample parameter values
    sampled = ranges(:,1) + rand(size(ranges,1),1) .* (ranges(:,2) - ranges(:,1));
    alpha1 = sampled(1); alpha2 = sampled(2); alpha3 = sampled(3);
    q1 = sampled(4); q2 = sampled(5); gamma = sampled(6);
    beta = sampled(7); a1 = sampled(8); a2 = sampled(9); a3 = sampled(10);
    d1 = sampled(11); d2 = sampled(12); d3 = sampled(13);
    p10 = sampled(14); p20 = sampled(15); p3 = sampled(16);
    p11 = sampled(17); p21 = sampled(18); p12 = sampled(19); p22 = sampled(20);
    delta = sampled(21); xi = sampled(22); phi = sampled(23); eta = sampled(24);

    % % Assume fixed values for c3, omega, y (or sample within range as needed)
    % c3 = 0.5; omega = 0.5; y = 1.0;

    % Sample biologically meaningful values for state variables
c1 = 0.1 + rand() * 0.8;        % Normal cells in (0.1, 0.9)
c2 = 0.1 + rand() * 0.8;        % Cancer cells in (0.1, 0.9)
c3 = 0.1 + rand() * 0.8;        % Endothelial cells in (0.1, 0.9)
omega = 0.01 + rand() * 0.49;   % Anti-angiogenic agent in (0.01, 0.5)
y = 0.01 + rand() * 0.49;       % Chemotherapy agent in (0.01, 0.5)


    % Updated drug response functions
    p1 = p10 + p11 * c3 + p12 * omega;
    p2 = p20 + p21 * c3 + p22 * omega;
    % p3 unchanged: already sampled

    % Ensure powers defined in (0,1)
    c1 = min(0.9, 0.8); c2 = min(0.9, 0.6); c3 = min(0.9, c3);

    % Diffusion coefficients
    D2 = 0.001; D3 = 0.001; D4 = 0.001; D5 = 0.001;
    
    % Jacobian entries 
    m1 = alpha1 * (q1 * c1^(q1-1) * (1-c1)^q2 - c1^q1 * q2 * (1-c1)^(q2-1)) ...
       - p1*y*a1/(a1 + c1)^2;
    m2 = - p1 * c1 / (a1 + c1);
    m4 = m2;
    m5 = - c1 * y * p12 / (a1 + c1);

    v1 = - p2 * c1 / (a2 + c2);
    term1 = alpha2 * q1 * c2^(q1-1) * (1 - c2/(1 + gamma * c3))^q2;
    term2 = alpha2 * c2^q1 * q2 * (1 - c2/(1 + gamma * c3))^(q2 - 1) * (-1 / (1 + gamma * c3));
    v2 = term1 + term2 - p2*y*a2/(a2 + c2)^2;
    v3 = alpha2 * c2^q1 * q2 * (1 - c2 / (1 + gamma * c3))^(q2 - 1) * ...
         (c2 * gamma / (1 + gamma * c3)^2);
    v4 = - p2 * c2 / (a2 + c2);
    v5 = p22 * c2 * y / (a2 + c2);

    g2 = 0.01;
    g3 = - alpha3 * q1 * c3^(q1 - 1) * (1 - c3)^q2 ...
         + alpha3 * c3^q1 * q2 * (1 - c3)^(q2 - 1) ...
         - p3 * a3 / (a3 + c3)^2;
    g5 = - p3 * c3 / (a3 + c3);

    f1 = y * d1 * a1 / (a1 + c1)^2;
    f2 = y * d2 * a2 / (a2 + c2)^2;
    f4 = - (delta + d1 * c1 / (a1 + c1) + d2 * c2 / (a2 + c2));

    z3 = a3 * omega / (a3 + c3)^2;
    z5 = - (eta + a3 * c3 / (a3 + c3));

    % Wavenumbers and dispersion relation
    k_vals = linspace(0, 2, 200);
    max_real_part = zeros(size(k_vals));

    for i = 1:length(k_vals)
        k = k_vals(i);
        Jk = [ ...
            m1,    m2,     0,      m4,            m5;
            v1,    v2 - D2*k^2, v3, v4,           v5;
            0,     g2,     g3 - D3*k^2, 0,        g5;
            f1,    f2,     0,      f4 - D4*k^2,   0;
            0,     0,      z3,     0,             z5 - D5*k^2];
        max_real_part(i) = max(real(eig(Jk)));
    end

    % Plot dispersion relation
    figure;
    plot(k_vals, max_real_part, 'LineWidth', 2);
    yline(0, '--k');
    xlabel('Wavenumber k');
    ylabel('Max Re(\\lambda)');
    title('Turing Instability: Dispersion Relation');
    grid on;
end
