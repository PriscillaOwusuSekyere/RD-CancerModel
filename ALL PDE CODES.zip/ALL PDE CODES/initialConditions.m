function u0 = initialConditions(x, y0)
    % Initial conditions with noise
    noiseLevel = 0.001; % Adjust the noise level as needed
    noise = noiseLevel * randn(size(y0)); % Gaussian noise

   % u0 = .0+noise+exp(-0.16*x^2)+0.5*exp(-0.26*(x-10)^2)-0.02*exp(-0.5*(x-7)^2)-0.02*exp(-0.5*(x-3)^2); % Add noise to the initial conditions
   % u0 = y0 ;
   %u0 = y0 + noise;

% Kindly find below the initial conditions used for each stage of cancer 

   % u0 = .001+noise+0.1*exp(-.9*(x-5).^2)+0.1*exp(-0.9*(x-9).^2);stage 4
   %u0 = .001+noise+0.1*exp(-6.8*(x-5).^2)+0*exp(-3.8*(x-8).^2);%stage 1 simulation
   %u0 = .001+noise+0.05*exp(-1.5*(x-5).^2)+0*exp(-3.8*(x-8).^2);%stage 2 simulation
   %u0 = .001+noise+0.1*exp(-.6*(x-5).^2)+0*exp(-3.8*(x-8).^2);%stage 3 chemo and Anti

   %u0 = .001+noise+0.01*exp(-.3*(x-8).^2)+0*exp(-3.8*(x-8).^2);%stage 3 no Chemo and No Anti
   %u0 = .01+noise+0.01*exp(-.3*(x-8).^2)+0*exp(-3.8*(x-8).^2);%stage 3 no Chemo and No Anti new

   %u0 = .001+noise+0.1*exp(-.9*(x-5).^2)+0.1*exp(-0.9*(x-9).^2);%stage 4- all three present
   %u0 = .001+noise+0.05*exp(-.9*(x-5).^2)+0.1*exp(-0.9*(x-9).^2); %stage 4- no Chemo but Immu and Anti present
   %u0 = .001+noise+0.5*exp(-2.8*(x-3).^2)+0.5*exp(-4.8*(x-6).^2); % stage 4 case 3 none of the 3 therapies
   %u0 = .001+noise+0.05*exp(-.9*(x-4).^2)+0.1*exp(-0.9*(x-8).^2); 

   %u0 = .001+noise+0.01*exp(-.9*(x-5).^2)+0.1*exp(-0.9*(x-9).^2); %stage 4 no anti but both present
   %u0 = .001+noise+0.1*exp(-1.1*(x-5).^2)+0.1*exp(-1.1*(x-8).^2);%stage 4 no immu but both present
   
   %u0 = .001+noise+0.5*exp(-.4*(x-5).^2)+0.5*exp(-0.9*(x-9).^2);
   
    
end
