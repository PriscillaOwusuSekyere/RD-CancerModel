clc 
clear

    %original values from the paper
    alpha_1=0.0068;
    alpha_2=0.01;      
    alpha_3=0.002;  
    q_1=0.00702;
    q_2=0.00072;  
    gamma=0.1615; 
    beta=0.00371;
    a_1=1.10;  
    a_2=4.6205;  
    a_3=4.6666;
    d_1=0.0002;
    d_2=0.032;
    d_3=0.032;  
    P_10=0.00000012;
    P_20=0.2051;
    P_3=1.7143; %This have being updated
    P_11=0.000000042;
    P_12=0.00000010;
    P_21=0.00431;  
    P_22=19.4872;  
    delta=0.0033;
    zi=0.01813 ;
    phi=0.00024;
    eta=0.136;
    r1=1;
   s1=1;
   r2=1;
   s2=1;
   r3=1;
   s3=1;
    



   cases=2;

% we want a gamma distriburation tilted to the right
% https://en.wikipedia.org/wiki/Gamma_distribution
% Parameters for the gamma distribution
shape = 9;          % shape parameter
scale = 3/shape;    % scale parameter
ns=3000;

% Generate ns=30 samples from the gamma distribution
samples1 = gamrnd(shape, scale, ns, 1);
samples2 = gamrnd(shape, scale, ns, 1);
% Clip the samples to be between 1 and 5
samples1(samples1 < 0) = 0;
samples1(samples1 > 12) = 12;
samples2(samples2 < 0) = 0;
samples2(samples2 > 12) = 12;

   if cases ==1
   r1=2 ;
   r2=3;
   vr1=samples1;
   vr2=samples2;
   s1=1;
   s2=1;
      figure;
        
h1 = histogram(vr1);
hold on
h2 = histogram(vr2);
h1.Normalization = 'probability';
h1.BinWidth = 0.15;
h2.Normalization = 'probability';
h2.BinWidth = 0.15;
   legend
   elseif cases ==2
   r1=1; 
   r2=1;
   s1=2;
   s2=3;
   vs1=samples1;
   vs2=samples2;
         figure;
h1 = histogram(vs1);
hold on
h2 = histogram(vs2);
h1.Normalization = 'probability';
h1.BinWidth = 0.15;
h2.Normalization = 'probability';
h2.BinWidth = 0.15;
   legend
   end
  
figure
for i=1:ns
    i
   if cases ==1
        p=[alpha_1, alpha_2 , alpha_3 ,  q_1 , q_2 , gamma,  beta ,   a_1 ,   a_2 ,  a_3 , d_1 , d_2 ,  d_3 ,  P_10 ,  P_20 ,  P_3 , P_11 , P_12 ,   P_21 ,   P_22 ,   delta ,  zi ,  phi ,  eta , vr1(i), s1 ,vr2(i) , s2 , r3 ,  s3];
   elseif cases ==2
p=[alpha_1, alpha_2 , alpha_3 ,  q_1 , q_2 , gamma,  beta ,   a_1 ,   a_2 ,  a_3 , d_1 , d_2 ,  d_3 ,  P_10 ,  P_20 ,  P_3 , P_11 , P_12 ,   P_21 ,   P_22 ,   delta ,  zi ,  phi ,  eta , r1 , vs1(i) , r2 , vs2(i) , r3 ,  s3];
    end    
 options = odeset('RelTol',1e-4,'AbsTol',[1e-4 1e-5 1e-6 1e-7 1e-8]);
[T,Y] = ode45(@BDModifiedAnti_angeogenensis_modelNew,[0 10000],[.1  .1  .1  0  0],options,p);
%plot(T, Y(:,1), '-', T, Y(:,2), '-.r', T, Y(:,3), '--g', T, Y(:,4), ':c', T, Y(:,5), '-m', 'LineWidth', 2.5)
%plot(T, Y(:,1), '.-b',T, Y(:,2), '-r',T, Y(:,3),'-g','linewidth',1)
plot(T, Y(:,1), '.-b')
xlabel( 'time','FontWeight','bold')
ylabel( 'X_1', 'FontWeight','bold')
%title('numerical simulation ' ,'FontWeight','bold')
%title('this is x_1');
%legend('X_1','X_2','X_3')
grid on
%hold on
%pause(1)
  % end
hold on

   %     if cases ==1 && max(Y(:,1))<0.2
   %      aSample=[vr1(i) ,  vr3(i)]  
   % elseif cases ==2 && max(Y(:,1))<0.2
   % bSample=[vs1(i) ,  vs3(i)]  
   y1(i)=Y(end,1);
   y2(i)=Y(end,2);
   y3(i)=Y(end,3);
   y4(i)=Y(end,4);
   y5(i)=Y(end,5);   
end    

%%%%% here we generate the bifurcation diagrams


   if cases ==1
      %  vr1 %vr3(i) ,  s3];
        figure
%         plot(vr1,y1,'or','LineWidth',2)
%         grid on
% xlabel( 'r_1','FontWeight','bold')
% ylabel( 'X_1', 'FontWeight','bold')
% title('this is the bifurcation diagram for r_1 and x_1');

% Sample data
x = vr1; % x values
y = vr2; % y values
z = y5; % z values

% Define grid for interpolation
xi = linspace(min(x), max(x), 100); % x values for interpolation
yi = linspace(min(y), max(y), 100); % y values for interpolation
[XI, YI] = meshgrid(xi, yi); % Create a grid of xi and yi values

% Interpolate z values
ZI = griddata(x, y, z, XI, YI, 'cubic'); % Cubic interpolation

% Plot the interpolated surface
figure; % Create a new figure
surf(XI, YI, ZI); % Generate the interpolated surface plot
xlabel('r1-axis'); % Label for x-axis
ylabel('r2-axis'); % Label for y-axis
zlabel('w-axis'); % Label for z-axis
%title('Bifurcation diagram of x_1 based on a_1 and a_3'); % Title for the plot
colorbar; % Display color bar


   elseif cases ==2
%vr1% , r3 ,  vs3(i)];
      %  vr1 %vr3(i) ,  s3];
        figure
%         plot(vr1,y1,'or','LineWidth',2)
%         grid on
% xlabel( 'r_1','FontWeight','bold')
% ylabel( 'X_1', 'FontWeight','bold')
% title('this is the bifurcation diagram for r_1 and x_1');

% Sample data
x = vs1; % x values
y = vs2; % y values
z = real(y5); % z values

% Define grid for interpolation
xi = linspace(min(x), max(x), 100); % x values for interpolation
yi = linspace(min(y), max(y), 100); % y values for interpolation
[XI, YI] = meshgrid(xi, yi); % Create a grid of xi and yi values

% Interpolate z values
ZI = griddata(x, y, z, XI, YI, 'cubic'); % Cubic interpolation

% Plot the interpolated surface
figure; % Create a new figure
surf(XI, YI, ZI); % Generate the interpolated surface plot
xlabel('s1-axis'); % Label for x-axis
ylabel('s2-axis'); % Label for y-axis
zlabel('w-axis'); % Label for z-axis
%title('Bifurcation diagram of x_1 based on r_1 and r_3'); % Title for the plot
colorbar; % Display color bar

    end 
     
