function F = rootCM(y,p)

    % Extract variables from input vector y
    y1 = y(1);
    y2 = y(2);
    y3 = y(3);
    y4 = y(4);
    y5 = y(5);


   alpha_1=p(1);
alpha_2=p(2);
alpha_3=p(3);
q_1=p(4);
q_2=p(5);
gamma=p(6);
beta =p(7);
a_1 =p(8);
a_2 =p(9);
a_3=p(10); 
d_1 =p(11);
d_2=p(12); 
d_3=p(13); 
P_10=p(14); 
P_20 =p(15);
P_3 =p(16); 
P_11 =p(17);
P_21 =p(18);   
P_12 =p(19);
P_22=p(20); 
delta=p(21); 
xi =p(22);
phi =p(23);
eta =p(24);
r1=p(25);
s1 =p(26);
r3 =p(27);
s3=p(28);
r2=p(29);
s2=p(30); 

F(1) = (alpha_1 * (y1^r1) * (1 - y1)^s1) - q_1 * y1 * y2 - (P_10+P_11*y3+P_12*y5) * ((y1*y4)/((a_1)+y1));
F(2) = alpha_2 * (y2^r2) * ((1 - (y2/(1 + gamma * y3)))^s2) - (q_2 * y1 * y2) - (P_20 + P_21*y3+P_22*y5) * ((y2*y4)/((a_2)+y2));
F(3) =beta*y2 + alpha_3 * (y3^r3)*((1 - y3))^s3 - ((P_3 * y3 * y5) / ((a_3) + y3));
F(4) =delta - (xi + (d_1*y1)/(a_1 + y1) + (d_2*y2)/(a_2 + y2) ) * y4;
F(5) = phi - (eta + (d_3*y3)/(a_3 + y3)) * y5;






