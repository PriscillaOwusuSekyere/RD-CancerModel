function ode_jacobian_stability()
    rng(42); % For reproducibility

    % Parameter ranges [min, max]
    ranges = [ ...
        6.8e-3, 0.0143;     % alpha1
        1.0e-3, 0.0210;     % alpha2
        2.0e-4, 0.0042;     % alpha3
        7.02e-4, 0.0147;    % q1
        7.2e-5, 0.0015;     % q2
        0.0162, 0.3392;     % gamma
        3.71e-4, 0.0078;    % beta
        0.1100, 2.3100;     % a1
        0.4621, 9.7030;     % a2
        0.4667, 9.7999;     % a3
        2e-5, 4.2e-4;       % d1
        0.0032, 0.0672;     % d2
        0.0032, 0.0672;     % d3
        1.2e-8, 2.52e-7;    % p10
        0.0205, 0.4307;     % p20
        0.1714, 3.6;        % p3
        4.2e-9, 8.82e-8;    % p11
        4.31e-4, 0.0091;    % p21
        1.0e-8, 2.1e-7;     % p12
        1.9487, 40.9231;    % p22
        3.3e-4, 0.0069;     % delta
        0.0018, 0.0381;     % xi
        2.4e-5, 5.04e-4;    % phi
        0.0136, 0.2856      % eta
    ];

    sampled = ranges(:,1) + rand(size(ranges,1),1) .* (ranges(:,2) - ranges(:,1));

    alpha1 = sampled(1); alpha2 = sampled(2); alpha3 = sampled(3);
    q1 = sampled(4); q2 = sampled(5); gamma = sampled(6);
    beta = sampled(7); a1 = sampled(8); a2 = sampled(9); a3 = sampled(10);
    d1 = sampled(11); d2 = sampled(12); d3 = sampled(13);
    p10 = sampled(14); p20 = sampled(15); p3 = sampled(16);
    p11 = sampled(17); p21 = sampled(18); p12 = sampled(19); p22 = sampled(20);
    delta = sampled(21); xi = sampled(22); phi = sampled(23); eta = sampled(24);

    % Biologically realistic steady state values
    c1 = 0.8; c2 = 0.6; c3 = 0.7; omega = 0.3; y = 0.2;

    % Drug response parameters
    p1 = p10 + p11 * c3 + p12 * omega;
    p2 = p20 + p21 * c3 + p22 * omega;

    % Jacobian for the ODE system (no diffusion)
    m1 = alpha1 * (q1 * c1^(q1-1) * (1-c1)^q2 - c1^q1 * q2 * (1-c1)^(q2-1)) - p1*y*a1/(a1 + c1)^2;
    m2 = - p1 * c1 / (a1 + c1);
    m4 = m2;
    m5 = - c1 * y * p12 / (a1 + c1);

    v1 = - p2 * c1 / (a2 + c2);
    term1 = alpha2 * q1 * c2^(q1-1) * (1 - c2/(1 + gamma * c3))^q2;
    term2 = alpha2 * c2^q1 * q2 * (1 - c2/(1 + gamma * c3))^(q2 - 1) * (-1 / (1 + gamma * c3));
    v2 = term1 + term2 - p2*y*a2/(a2 + c2)^2;
    v3 = alpha2 * c2^q1 * q2 * (1 - c2 / (1 + gamma * c3))^(q2 - 1) * (c2 * gamma / (1 + gamma * c3)^2);
    v4 = - p2 * c2 / (a2 + c2);
    v5 = p22 * c2 * y / (a2 + c2);

    g2 = 0.01;
    g3 = - alpha3 * q1 * c3^(q1 - 1) * (1 - c3)^q2 + alpha3 * c3^q1 * q2 * (1 - c3)^(q2 - 1) - p3 * a3 / (a3 + c3)^2;
    g5 = - p3 * c3 / (a3 + c3);

    f1 = y * d1 * a1 / (a1 + c1)^2;
    f2 = y * d2 * a2 / (a2 + c2)^2;
    f4 = - (delta + d1 * c1 / (a1 + c1) + d2 * c2 / (a2 + c2));

    z3 = a3 * omega / (a3 + c3)^2;
    z5 = - (eta + a3 * c3 / (a3 + c3));

    J = [ ...
        m1,    m2,     0,    m4,   m5;
        v1,    v2,    v3,    v4,   v5;
        0,     g2,    g3,    0,    g5;
        f1,    f2,     0,    f4,    0;
        0,     0,     z3,    0,   z5];

    % Compute eigenvalues
    lambda = eig(J);

    disp('Eigenvalues of the ODE system Jacobian:');
    disp(lambda);

    % Plot real parts
    figure;
    plot(real(lambda), imag(lambda), 'o', 'MarkerSize', 10);
    xlabel('Re(\lambda)'); ylabel('Im(\lambda)');
    title('Eigenvalues of the ODE Jacobian');
    grid on;
end
