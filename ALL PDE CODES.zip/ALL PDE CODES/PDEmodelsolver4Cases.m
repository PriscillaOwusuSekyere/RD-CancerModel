%Cancer that comes back shortly after treatment is called a progression, 
% not a recurrence, according to many oncologists. Progression is when cancer worsens 


%%% in this code we simulate a case of progression in two years =730 days



clear
clc
global sc
sc=1;
%cases=1; % this is for general case
%cases=2; % this is for relapse case  (we use a differnet initial condition)
cases=3  %this generates  relapse in short term less than 50 days

% alpha_1=pw(1);
% alpha_2=pw(2);
% alpha_3=pw(3);
% q_1=pw(4);
% q_2=pw(5);
% gamma=pw(6);
% beta =pw(7);
% a_1 =pw(8);
% a_2 =pw(9);
% a_3=pw(10); 
% d_1 =pw(11);
% d_2=pw(12); 
% d_3=pw(13); 
% P_10=pw(14); 
% P_20 =pw(15);
% P_3 =pw(16); 
% P_11 =pw(17);
% P_21 =pw(18);   
% P_12 =pw(19);
% P_22=pw(20); 
% delta=pw(21); 
% zi =pw(22);
% phi =pw(23);
% eta =pw(24);
% r1=pw(25);
% s1 =pw(26);
% r3 =pw(27);
% s3=pw(28);
% r2=pw(29);
% s2=pw(30);

 
%original values from the paper
    alpha_1=0.0068;
    alpha_2=0.01;      
    alpha_3=0.002;  
    q_1=0.00702;
    q_2=0.00072;  
    gamma=0.1615; 
    beta=0.00371;
    a_1=1.10;  
    a_2=4.6205;  
    a_3=4.6666;
    d_1=0;%0.0002;
    d_2=0;%0.032;
    d_3=0;%0.032;  %0.032+0.5 % 0.032;  
    P_10=0.00000012;
    P_20=0.2051;
    P_3=1.7143; %This have being updated
P_11=0.000000042;
    P_12=0.00000010;
    P_21=0.00431;  
    P_22=19.4872;  
    delta=0;%0.0033+0.01;
    zi=0;%0.01813+0.01;
    phi=0;%0.00024;%0.00024
    eta=0;%0.136;%0.136
    r1=1;
   s1=1;
   r3=1;
   s3=1;
   r2=1;  %  you can increase this to 2 and see the effect of the Immunotherapy
   s2=1;



TimeEnd=200;
n=2
%pw=A2(3,:);

    % Spatial domain
    x = linspace(0, 20, 1000);
    
    % Time domain
    t = linspace(0, TimeEnd, n*TimeEnd);

%results for A2  (this is when s1=2)
%cases=1 of interest: 3=nice relapse, 13=cancerfree,
%cases=2 of interest 3=relapse within 2,000 days  lots of cases of blowing up

%results for A1 (this is when s1=1, i.e., we have the original model)
%cases=1 of interest: 4=bistable, 5=bistable+oscillations,
%cases=2 of interest 3=relapse within 2,000 days  5 and 5=relapse within 10,000 days
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






format longG

% Parameters
    p = [alpha_1, alpha_2, alpha_3, q_1, q_2, gamma, beta, a_1, a_2, a_3, ...
         d_1, d_2, d_3, P_10, P_20, P_3, P_11, P_21, P_12, P_22, ...
         delta, zi, phi, eta, r1, s1, r3, s3, r2, s2];


% Find the Equilibrium solution and its stablity

    syms  y1 y2 y3 y4 y5 lambda2;


dy1=(alpha_1*(y1^r1)*(1-y1)^s1)-q_1*y1*y2-(P_10+P_11*y3+P_12*y5)*((y1*y4)/((a_1)+y1));
dy2=alpha_2*(y2^r2)*((1-(y2/(1+gamma*y3)))^s2)-(q_2*y1*y2)-(P_20+P_21*y3+P_22*y5)*((y2*y4)/((a_2)+y2));
dy3=beta*y2+alpha_3*(y3^r3)*((1-y3))^s3-((P_3*y3*y5)/((a_3)+y3));
dy4=delta-(zi+(d_1*y1)/(a_1+y1)+(d_2*y2)/(a_2+y2))*y4;
dy5=phi-(eta+(d_3*y3)/(a_3+y3))*y5;


%%%%%%% the command solve takes a long time. Therefore we use fsolve
%%%%%%% instead of solve
%eq = solve(dy1,dy2,dy3,dy4,dy5,y1,y2,y3,y4,y5);

 % Define the initial guess for [y1, y2, y3, y4, y5]
    initialGuess = [1, 1, 1, 1, 1];
% Set options for fsolve
    %options = optimoptions('fsolve', 'Display', 'iter');
    options = optimoptions('fsolve');
    % Call fsolve
    [solution, fval, exitflag, output] = fsolve(@(y) rootCM(y, p), initialGuess, options);
    
Eq=solution  %%%% this is the fixed point 

 
%%% stablity of the fixed point

 J=jacobian([dy1;dy2;dy3;dy4;dy5], [y1 y2 y3 y4 y5]); % this will generate the Jacobian Matrix
 Jeval1= subs(J,{y1,y2,y3,y4, y5},{solution(1), solution(2),solution(3),solution(4), solution(5)});%this will evaluate the Jacobian Matrix at the endmic equilibrium
 JE=double(Jeval1);
 charEQ1=det(Jeval1-lambda2*eye(5));% this is the char eq. corresponding to the first equilibrium i.e. equil1.
eigen1=solve(charEQ1,lambda2);
char_polynomial=vpa(charEQ1);
eigs=double(eigen1)  %%%% these are the eigenvalues



    % Solve the ODE problem to get boundary values
if cases==1
y0=[solution(1)+rand, solution(2)+rand,solution(3)+rand,solution(4)+rand, solution(5)+rand];
elseif cases==2
y0=[solution(1)+1, solution(2)+.1,solution(3)+.1,solution(4)+.5, solution(5)+1];
elseif cases==3  %this generates  relapse in short term less than 50 days
    y0=[0.562495136638244 0.0519199176953032  0.697752060433105    0.591399495639053   0.221873320120404];
end
%%% you can also try: y0=[0.562495136638244 1.19199176953032  0.697752060433105    0.591399495639053   0.221873320120404];


 tspan = [0, TimeEnd];

    [T, y] = ode45(@(t,y)ModifiedAnti_angeogenensis_modelNew(t,y,p), tspan, y0);

   
 %    figure
 % 
 % plot(T, y(:,1), '-', T, y(:,2), '-.r', T, y(:,3), '--g', T, y(:,4), ':c', T, y(:,5), '-m', 'LineWidth', 1.5)
 %    ylabel('ODE solution')
 %    legend('normal cells','cancer cells','endo cells','chem drug','anti drug')

    % Get boundary values from the ODE solution
    leftBoundaryValues = y(1, :);
    rightBoundaryValues = y(end, :);

tValues=T;
uValues=y;



       % Solve PDE
 sol = pdepe(0, @(x,t,u,DuDx)pdeFunction(x,t,u,DuDx,p), ...
                @(x)initialConditions(x, y0'), ...
                @(xl,ul,xr,ur,t)boundaryConditions(xl,ul,xr,ur,t,tValues,uValues), ...
                x, t);

    % Extract solution
    u1 = sol(:,:,1);
    u2 = sol(:,:,2);
    u3 = sol(:,:,3);
    u4 = sol(:,:,4);
    u5 = sol(:,:,5);

%     % Plot results
%     figure;
%     surf(x, t, u1);
%     title('Solution u1');
%     xlabel('x');
%     ylabel('t');
%     zlabel('u1');

%     figure;
%     surf(x, t, u2);
%     title('Solution u2');
%     xlabel('x');
%     ylabel('t');
%     zlabel('u2');
%     colorbar

    % Add more plots as needed for u3, u4, u5

%%%%%%%% here we plot a subset of the points because there are too many
%%%%%%%% points
figure;
subsetInterval = 1;
surf(x(1:subsetInterval:end), t(1:subsetInterval:end), u2(1:subsetInterval:end, 1:subsetInterval:end), 'EdgeColor', 'none');
colormap(jet);
colorbar;
%title('Surface u(x,t) Solution of Cancer cell with tumor');
xlabel('Distance (x)');
ylabel('Time (t)');
zlabel('u');
view(-30, 30);
light('Position', [1 0 1], 'Style', 'infinite');
lighting gouraud;
alpha(0.9);


% Area under the curve estimation at t=0 and t=end
% Assuming u2 is organized such that u2(:, 1) is at t=0 and u2(:, end) is at t=end
% If x is not uniformly spaced, ensure x is the same size as u2(:, 1)


% Area under the curve estimation at t=0 and t=end
area_0 = trapz(x, u2(1,:)); % Area at t=0
area_end = trapz(x, u2(end,:)); % Area at t=end
percent_change = ((area_end - area_0) / area_0) * 100; % Percent change

cz=size(u2);
t_length=cz(1);
x_length=cz(2);

for ic=1:t_length
vec_Area(ic)=trapz(x, u2(ic,:));
end
figure
plot(t, vec_Area,'--r', 'Linewidth',1)
xlabel('Time,days');
ylabel('Area under the curve A(t)');
grid on


% Estimate radius based on area assuming circular cross-section
r_0 = sqrt(area_0 / pi); % Radius at t=0
r_end = sqrt(area_end / pi); % Radius at t=end

% Compute volumes based on estimated radii
V_0 = (4/3) * pi * (r_0^3); % Volume at t=0
V_end = (4/3) * pi * (r_end^3); % Volume at t=end

% Display results
disp(['Area at t=0: ', num2str(area_0)]);
disp(['Area at t=end: ', num2str(area_end)]);
disp(['Percent Change: ', num2str(percent_change), '%']);
disp(['Radius (r) at t=0: ', num2str(r_0)]);
disp(['Volume of Tumor at t=0: ', num2str(V_0)]);
disp(['Radius (r) at t=end: ', num2str(r_end)]);
disp(['Volume of Tumor at t=end: ', num2str(V_end)]);



