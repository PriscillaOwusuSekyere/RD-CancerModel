function [pl,ql,pr,qr] = boundaryConditions(xl,ul,xr,ur,t,tValues,uValues)

uValues1=uValues(:,1);
uValues2=uValues(:,2);
uValues3=uValues(:,3);
uValues4=uValues(:,4);
uValues5=uValues(:,5);


pp1 = spline(tValues,uValues1);
pp2 = spline(tValues,uValues2);
pp3 = spline(tValues,uValues3);
pp4 = spline(tValues,uValues4);
pp5 = spline(tValues,uValues5);

BoundaryValues_left1 = ppval(pp1, t);
BoundaryValues_left2 = ppval(pp2, t);
BoundaryValues_left3 = ppval(pp3, t);
BoundaryValues_left4 = ppval(pp4, t);
BoundaryValues_left5 = ppval(pp5, t);

leftBoundaryValues=[BoundaryValues_left1 BoundaryValues_left2...
    BoundaryValues_left3 BoundaryValues_left4 BoundaryValues_left5];


%%%%%%%%%%%%%%% this for zero-dirichlet BC
%leftBoundaryValues=zeros(1,5);




% t
% if t<54
%     rightBoundaryValues=zeros(1,5);
% else
% rightBoundaryValues=leftBoundaryValues;
% end

rightBoundaryValues=leftBoundaryValues;
%Left boundary conditions (Dirichlet)
    pl = ul;% - leftBoundaryValues';
    ql = [0; 0; 0; 0; 0]; % Dirichlet boundary conditions

    % Right boundary conditions (Dirichlet)
    pr = ur;% - rightBoundaryValues';
    qr = [0; 0; 0; 0; 0]; % Dirichlet boundary conditions
end